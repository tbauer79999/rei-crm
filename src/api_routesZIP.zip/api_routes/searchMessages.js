const express = require('express');
const router = express.Router();
const { supabase } = require('../../lib/supabaseClient');

// GET /api/messages/search?keyword=xxx&tenant_id=yyy
router.get('/', async (req, res) => {
  const { keyword, tenant_id } = req.query;

  if (!keyword || !tenant_id) {
    return res.status(400).json({ error: 'Missing keyword or tenant_id' });
  }

  try {
    const { data, error } = await supabase
      .from('messages')
      .select('id, message_body, property_id, phone, timestamp')
      .ilike('message_body', `%${keyword}%`)
      .eq('tenant_id', tenant_id)
      .order('timestamp', { ascending: false });

    if (error) throw error;

    res.json(data);
  } catch (err) {
    console.error('Keyword search error:', err);
    res.status(500).json({ error: 'Failed to fetch messages', details: err });
  }
});

module.exports = router;
